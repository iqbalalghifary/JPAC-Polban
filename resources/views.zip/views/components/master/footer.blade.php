<footer class="main-footer">
    <div class="footer-left">Copyright © Pusat Karir POLBAN - 2023</div>
    <div class="footer-right">Developed by IT Team of JTK Polban</div>
</footer>
